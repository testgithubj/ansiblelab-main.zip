# ansiblelab
Anisble Lab Practice


Today Project Agenda
---
1. Install Nginx on Ubuntu 20.04
2. Configure Nginx
3. Deploy a web application

Execution Plan
---
declare variables if needed
role
Task
templates
files
vars
inventory
